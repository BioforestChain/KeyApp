const e={messagePrefix:`Bitcoin Signed Message:
`,bech32:"bc",bip32:{public:76067358,private:76066276},pubKeyHash:0,scriptHash:5,wif:128},i={messagePrefix:`Bitcoin Signed Message:
`,bech32:"bcrt",bip32:{public:70617039,private:70615956},pubKeyHash:111,scriptHash:196,wif:239},s={messagePrefix:`Bitcoin Signed Message:
`,bech32:"tb",bip32:{public:70617039,private:70615956},pubKeyHash:111,scriptHash:196,wif:239};export{e as b,i as r,s as t};
