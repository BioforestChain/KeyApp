import"./page-BnBmgj2e.js";const i=async t=>{await navigator.clipboard.writeText(t)};export{i as w};
