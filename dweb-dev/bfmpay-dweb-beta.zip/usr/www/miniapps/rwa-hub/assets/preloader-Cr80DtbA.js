import{j as o}from"./index-AshhoVut.js";import{K as e}from"./page-BnBmgj2e.js";const a=r=>o.jsx(e,{size:24,...r});export{a as P};
