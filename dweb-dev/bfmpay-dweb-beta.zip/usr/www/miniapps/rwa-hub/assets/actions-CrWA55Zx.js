import{f as o,A as a}from"./index-AshhoVut.js";await o.loadModule(a);
