import{L as s}from"./list-DTz1iW3n.js";const o=s;export{o as L};
